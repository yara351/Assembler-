#ifndef PASS2_H
#define PASS2_H


class pass2
{
    public:
        pass2();
        virtual ~pass2();

    protected:

    private:
};

#endif // PASS2_H
