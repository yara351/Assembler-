#include "pass2.h"

pass2::pass2()
{
    //ctor
}

pass2::~pass2()
{
    //dtor
}
