#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
 char instruction[10],operand[10],label[10];
  char mnemonic[15][15]={"START","LDA","ADD","DIV","MUL","STA","LDL","STL","LDCH","STCH","END"};// used to differ between instructions and variable declaration in code
  int locctr=0x0,j=0,len1,alen;
 FILE *fp1,*fp2,*fp3;

 fp1=fopen("INPUT.txt","r");
 fp2=fopen("SYMTAB.txt","w");
 fp3=fopen("OUT.txt","w");
 fscanf(fp1,"%s%s%s",label,instruction,operand);
 if(strcmp(instruction,"START")==0)
  {
   locctr=atoi(operand);
   fprintf(fp3,"%s\t%s\t%s\n",label,instruction,operand);
   fscanf(fp1,"%s%s%s",label,instruction,operand);
  }
 else
  locctr=0x0;
 while(strcmp(instruction,"END")!=0)
  {
      if(locctr<=0xf){
   fprintf(fp3,"000%x",locctr);
      }else{
      fprintf(fp3,"00%x",locctr);
      }
   if(strcmp(label,"++")!=0){
    if(locctr<=0xf){
     fprintf(fp2,"%s\t000%x\n",label,locctr);

    }else{
     fprintf(fp2,"%s\t00%x\n",label,locctr);
    }
   }

   while(strcmp(mnemonic[j],"END")!=0)// if the two strings are equal it return 0
    {
     if(strcmp(instruction,mnemonic[j])==0)
     {
      locctr+=0x3;

      break;
     }

     j++;
    }
   if(strcmp(instruction,"WORD")==0)
    locctr+=0x3;
   else if(strcmp(instruction,"RESW")==0)
    locctr+=(0x3*(atoi(operand)));
   else if(strcmp(instruction,"RESB")==0){

    locctr+=0x1*(atoi(operand));
   }
   else if(strcmp(instruction,"BYTE")==0){
        len1=strlen(operand);
    alen=len1-3;
    locctr=locctr+alen;
   }
   fprintf(fp3,"\t%s\t%s\t%s\n",label,instruction,operand);
   fscanf(fp1,"%s%s%s",label,instruction,operand);
  }
  fprintf(fp3,"00%x\t%s\t%s\t%s\n",locctr,label,instruction,operand);
   fclose(fp1);
    fclose(fp2);
    fclose(fp3);



  PASS2();

}
void PASS2()
{
  char a[10],ad[10],label[10],instruction[10],operand[10],symbol[10];
  int diff=0x0,st=0x0,i,address=0x0,add,len,actual_len,finaddr=0x0,prevaddr=0x0,j=0;
  char mnemonic[10][10]={"LDA","ADD","DIV","MUL","STA","LDL","STL","LDCH","STCH"};
  char opcode[15][15]={"00","18","24","20","0C","08","14","50","54"};
  FILE *fp1,*fp2,*fp3,*fp4;

  fp1=fopen("object_code.txt","w");
  fp2=fopen("SYMTAB.txt","r");
  fp3=fopen("OUT.txt","r");
  fp4=fopen("program_code.txt","w");
  fscanf(fp3,"%s%s%s",label,instruction,operand);

  while(strcmp(instruction,"END")!=0)//loop to get final address
  {
   prevaddr=address;// store address before final address
   fscanf(fp3,"%x%s%s%s",&address,label,instruction,operand);
  }
  finaddr=address;//store the final address
  fclose(fp3);
  fp3=fopen("OUT.txt","r");

  fscanf(fp3,"%s%s%s",label,instruction,operand);
  if(strcmp(instruction,"START")==0)
  {
   fprintf(fp1,"\t%s\t%s\t%s\n",label,instruction,operand);
   fprintf(fp4,"H^%s^00%s^00%x\n",label,operand,finaddr);
   fscanf(fp3,"%x%s%s%s",&address,label,instruction,operand);
   st=address;
   diff=prevaddr-st;//to get length of program
   fprintf(fp4,"T^00000%x^%x",address,diff);
  }
  while(strcmp(instruction,"END")!=0)
  {
   if(strcmp(instruction,"BYTE")==0)
   {
       if(address<=0xf){// if address represented in 1 number "print three zeros to make address 4 bits  "
    fprintf(fp1,"000%x\t%s\t%s\t%s\t",address,label,instruction,operand);
       }else{
       fprintf(fp1,"00%x\t%s\t%s\t%s\t",address,label,instruction,operand);

       }
    len=strlen(operand);
    actual_len=len-3;
    fprintf(fp4,"^");
    for(i=2;i<(actual_len+2);i++)
    {
     itoa(operand[i],ad,16);// change string to integer(int,string,base)
     fprintf(fp1,"%s",ad);
     fprintf(fp4,"%s",ad);
    }
    fprintf(fp1,"\n");
   }
   else if(strcmp(instruction,"WORD")==0)
   {
    len=strlen(operand);
    itoa(atoi(operand),a,16);// change string to integer(int,string,base)
     if(address<=0xf){// if address has represented in 1 number "print three zeros to make address 4 bits else print 2 zeros  "
            if(strlen(a)==1){// if the object code has represented in 1 number print five zeros to make object code 6 bits  else print four zeros
   fprintf(fp1,"000%x\t%s\t%s\t%s\t00000%s\n",address,label,instruction,operand,a);
            }else{
            fprintf(fp1,"000%x\t%s\t%s\t%s\t0000%s\n",address,label,instruction,operand,a);
            }
       }else{
    if(strlen(a)==1){
   fprintf(fp1,"00%x\t%s\t%s\t%s\t00000%s\n",address,label,instruction,operand,a);
            }else{
            fprintf(fp1,"00%x\t%s\t%s\t%s\t0000%s\n",address,label,instruction,operand,a);
            }
       }
       if(strlen(a)==1){// if the object code has represented in 1 number print five zeros to make object code 6 bits

    fprintf(fp4,"^00000%s",a);
       }else{
           fprintf(fp4,"^0000%s",a);

       }
   }
   else if((strcmp(instruction,"RESB")==0)||(strcmp(instruction,"RESW")==0)){
        if(address<=0xf){
    fprintf(fp1,"000%x\t%s\t%s\t%s\n",address,label,instruction,operand);
        }else{
            fprintf(fp1,"00%x\t%s\t%s\t%s\n",address,label,instruction,operand);

        }
   }else
   {
    while(strcmp(instruction,mnemonic[j])!=0){
     j++;
    }

     rewind(fp2);//sets the file position to the beginning of the file for the stream pointed to by stream. It also clears the error and end-of-file indicators for stream
     fscanf(fp2,"%s%x",symbol,&add);
      while(strcmp(operand,symbol)!=0){
       fscanf(fp2,"%s%x",symbol,&add);
      }
               if(address<=0xf){
      fprintf(fp1,"000%x\t%s\t%s\t%s\t%s00%x\n",address,label,instruction,operand,opcode[j],add);
        }else{
          fprintf(fp1,"00%x\t%s\t%s\t%s\t%s00%x\n",address,label,instruction,operand,opcode[j],add);

        }

     fprintf(fp4,"^%s00%x",opcode[j],add);

   }
   fscanf(fp3,"%x%s%s%s",&address,label,instruction,operand);
  }
   fprintf(fp1,"00%x\t%s\t%s\t%s\n",address,label,instruction,operand);
  fprintf(fp4,"\nE^00000%d",st);


}
